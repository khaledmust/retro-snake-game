#include <stdlib.h>
#include "gameobject.h"
#include "deque.h"

void GameObject_Food_Init(st_gameobject_food_t *self) {
    self->position.x = (float)GetRandomValue(0, 24);
    self->position.y = (float)GetRandomValue(0, 24);
    self->color = WHITE;
    self->ImagePath = "Graphics/food.png";
    Image image = LoadImage(self->ImagePath);
    self->texture = LoadTextureFromImage(image);
    UnloadImage(image);
    self->Draw = DrawTexture;

}

void GambeObject_Food_Deinit(st_gameobject_food_t *self) {
    UnloadTexture(self->texture);
}


static void GameObject_Snake_AppendHead(t_deque *SnakeNode, void *VectorCordinates) {
    pushFront(SnakeNode, VectorCordinates);
}


void GameObjedt_Snake_Init(st_gameobject_snake_t *self) {
    self->snake.first = NULL;
    self->snake.last = NULL;
    self->AppendToHead = GameObject_Snake_AppendHead;
    self->Draw = DrawRectangle;
}
